import requests as RS

id = '3'
mensagem = input("Digite o id da Mensagem: ")
url = 'http://127.0.0.1:80/responderMensagem2/{}/{}'.format(id, mensagem)
envio = {'De': id, 'Conteudo':"Resposta2"}
retorno = RS.api.post(url, json=envio).json()
print(retorno)
