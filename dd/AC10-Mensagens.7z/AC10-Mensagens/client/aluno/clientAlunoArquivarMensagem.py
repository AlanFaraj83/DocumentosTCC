import requests as RS
id = '3'
mensagem = input("Digite o id da Mensagem: ")
url = 'http://127.0.0.1:80/arquivarMensagem/{}/{}'.format(id, mensagem)
retorno = RS.api.get(url).json()
print(retorno)
