import requests as RS

aluno = ['1', '1', '3']
professor = ['4', '5', '5']
mensagem = ['Mensagem1', 'Mensagem2', 'Mensagem3']
for i in range(3):
    url = 'http://127.0.0.1:80/enviarMensagem/{}'.format(id)
    envio = {'De': aluno[i], 'Para': professor[i], 'Conteudo':mensagem[i]}
    retorno = RS.api.post(url, json=envio).json()
    print(retorno)
