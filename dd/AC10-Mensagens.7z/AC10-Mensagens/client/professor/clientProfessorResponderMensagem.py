import requests as RS

id = '5'
mensagem = input("Digite o id da Mensagem: ")
url = 'http://127.0.0.1:80/responderMensagem/{}/{}'.format(id, mensagem)
envio = {'De': id, 'Conteudo':"Resposta1"}
retorno = RS.api.post(url, json=envio).json()
print(retorno)
