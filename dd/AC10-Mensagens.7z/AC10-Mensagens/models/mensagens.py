Mensagens = [
    {'Id':'', 'De':'', 'Para':'', 'RespostaDo':'', 'Status': ''}
]

# Status:
# 0 - Nova
# 1 - Lida
# 2 - Arquivada
