import sys
from pathlib import Path
HERE = Path(__file__).parent
sys.path.append(str(HERE / '../../models'))
from flask import Flask as F, jsonify as J, request as R
from alunos import Alunos
from mensagens import Mensagens
from professores import Professores
import uuid

def alunoLerMensagemRecebida(id, status):
    dados = []
    for j in Mensagens:
        if j['Para'] == str(id):
            if str(status) == "3":
                for k in range(2,-1,-1):
                    if j['Para'] == str(id) and j['Status'] == str(k):
                        dados.append(j)
            elif j['Status'] == str(status):
                dados.append(j)
            if str(status) in ("0", "3") and j['Status'] == "0":
                j['Status'] = "1"
                for i in Alunos:
                    if i['Id'] == str(id):
                        i['Mensagens'] = str(int(i['Mensagens']) - 1)
                        break
    return(dados)
