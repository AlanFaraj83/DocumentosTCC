import sys
from pathlib import Path
HERE = Path(__file__).parent
sys.path.append(str(HERE / '../../models'))
from flask import Flask as F, jsonify as J, request as R
from alunos import Alunos
from mensagens import Mensagens
from professores import Professores
import uuid

def alunoResponderMensagem(id, mensagemId):
    mensagem = {}
    dados = R.get_json()
    for i in Alunos:
        if i['Id'] == dados['De']:
            for j in Mensagens:
                if j['Id'] == mensagemId:
                    mensagem['Id'] = str(uuid.uuid4())
                    mensagem['De'] = dados['De']
                    mensagem['Para'] = j['De']
                    mensagem['Conteudo'] = dados['Conteudo']
                    mensagem['RespostaA'] = j['Id']
                    mensagem['Status'] = '0'
                    Mensagens.append(mensagem)
                    for k in Professores:
                        if k['Id'] == str(id):
                            k['Mensagens'] = str(int(i['Mensagens']) + 1)
                        break
    return(mensagem)
