import sys
from pathlib import Path
HERE = Path(__file__).parent
sys.path.append(str(HERE / '../../models'))
from flask import Flask as F, jsonify as J, request as R
from alunos import Alunos
from mensagens import Mensagens
from professores import Professores
import uuid

def alunoDeletarMensagem(id, idMensagem):
    for i in Mensagens:
        if i['Id'] == str(idMensagem) and i['Para'] == str(id):
            Mensagens.remove(i)
            return(i['Id'])
