import sys
from pathlib import Path
HERE = Path(__file__).parent
sys.path.append(str(HERE / '../../models'))
from flask import Flask as F, jsonify as J, request as R
from alunos import Alunos
from mensagens import Mensagens
from professores import Professores
import uuid

def enviarMensagem(id):
    mensagem = {}
    dados = R.get_json()
    for i in Alunos:
        if i['Id'] == dados['De']:
            for j in Professores:
                if j['Id'] == dados['Para']:
                    mensagem['Id'] = str(uuid.uuid4())
                    mensagem['De'] = dados ['De']
                    mensagem['Para'] = dados ['Para']
                    mensagem['Conteudo'] = dados['Conteudo']
                    mensagem['RespostaA'] = ''
                    mensagem['Status'] = '0'
                    Mensagens.append(mensagem)
                    j['Mensagens'] = str(int(j['Mensagens']) + 1)
                    return(mensagem)
