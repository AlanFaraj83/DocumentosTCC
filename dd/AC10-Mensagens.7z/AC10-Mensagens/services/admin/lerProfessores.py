import sys
from pathlib import Path
HERE = Path(__file__).parent
sys.path.append(str(HERE / '../../models'))
from flask import Flask as F, jsonify as J, request as R
from professores import Professores
import uuid

def lerProfessores():
    return(Professores)
