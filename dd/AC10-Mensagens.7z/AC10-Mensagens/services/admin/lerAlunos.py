import sys
from pathlib import Path
HERE = Path(__file__).parent
sys.path.append(str(HERE / '../../models'))
from alunos import Alunos

def lerAlunos():
    return(Alunos)
