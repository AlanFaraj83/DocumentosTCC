from flask import Flask as F, jsonify as J, request as R

App = Flask(__name__)

from routes import *
from errorHandlers import *

if __name__ == '__main__':
    App.run(port=80, debug=True)
