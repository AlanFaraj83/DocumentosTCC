from flask import Flask as F, jsonify as J, request as R
from models.response import Response
from server import App

@App.errorhandler(400)
def badRequest(error):
    Response["Dados"] = ""
    Response["Mensagem"] = "Bad Request"
    Response["Status"] = "Error"
    return J(Response)

@App.errorhandler(403)
def forbidden(error):
    Response["Dados"] = ""
    Response["Mensagem"] = "Forbidden"
    Response["Status"] = "Error"
    return J(Response)

@App.errorhandler(404)
def notFound(error):
    Response["Dados"] = ""
    Response["Mensagem"] = "Not Found"
    Response["Status"] = "Error"
    return J(Response)

@App.errorhandler(500)
def internalServerError(error):
    Response["Dados"] = ""
    Response["Mensagem"] = "Internal Server Error"
    Response["Status"] = "Error"
    return J(Response)
