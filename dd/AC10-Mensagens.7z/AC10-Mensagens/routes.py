from flask import Flask as F, jsonify as J, request as R
from models.response import Response
from models.alunos import Alunos
from models.professores import Professores
from services.aluno.enviarMensagem import enviarMensagem
from services.professor.enviarMensagem import enviarMensagem2
from services.aluno.alunoArquivarMensagem import alunoArquivarMensagem
from services.aluno.alunoDeletarMensagem import alunoDeletarMensagem
from services.aluno.alunoLerMensagemRecebida import alunoLerMensagemRecebida
from services.professor.professorArquivarMensagem import professorArquivarMensagem
from services.professor.professorDeletarMensagem import professorDeletarMensagem
from services.professor.professorResponderMensagem import professorResponderMensagem
from services.aluno.alunoResponderMensagem import alunoResponderMensagem
from services.professor.professorLerMensagemRecebida import professorLerMensagemRecebida
from services.admin.lerMensagens import lerMensagens
from services.admin.lerProfessores import lerProfessores
from services.admin.lerAlunos import lerAlunos
from server import App

@App.route('/enviarMensagem/<id>', methods=['POST'])
def enviarMensagemIdPost(id):
    Response['Dados'] = enviarMensagem(id)
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Enviar Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Enviar Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)

@App.route('/arquivarMensagem/<id>/<mensagem>', methods=['GET'])
def arquivarMensagemIdMensagemGet(id, mensagem):
    for i in Professores:
        if i['Id'] == str(id):
            Response['Dados'] = professorArquivarMensagem(id, mensagem)
            break
    for i in Alunos:
        if i['Id'] == str(id):
            Response['Dados'] = alunoArquivarMensagem(id, mensagem)
            break
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Arquivar Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Arquivar Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)

@App.route('/deletarMensagem/<id>/<mensagem>', methods=['GET'])
def deletarMensagemIdMensagemGet(id, mensagem):
    for i in Professores:
        if i['Id'] == str(id):
            Response['Dados'] = professorDeletarMensagem(id, mensagem)
            break
    for i in Alunos:
        if i['Id'] == str(id):
            Response['Dados'] = alunoDeletarMensagem(id, mensagem)
            break
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Deletar Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Deletar Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)

@App.route('/lerMensagem/Recebida/<id>', methods=['GET'])
def lerMensagemRecebidaIdGet(id):
    for i in Professores:
        if i['Id'] == str(id):
            Response['Dados'] = professorLerMensagemRecebida(id, 3)
            break
    for i in Alunos:
        if i['Id'] == str(id):
            Response['Dados'] = alunoLerMensagemRecebida(id, 3)
            break
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Ler Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Ler Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)

@App.route('/lerMensagem/Recebida/<id>/<status>', methods=['GET'])
def lerMensagemRecebidaIdStatusGet(id, status):
    for i in Professores:
        if i['Id'] == str(id):
            Response['Dados'] = professorLerMensagemRecebida(id, status)
            break
    for i in Alunos:
        if i['Id'] == str(id):
            Response['Dados'] = alunoLerMensagemRecebida(id, status)
            break
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Ler Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Ler Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)

@App.route('/responderMensagem/<id>/<mensagem>', methods=['POST'])
def responderMensagemIdPost(id, mensagem):
    Response['Dados'] = professorResponderMensagem(id, mensagem)
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Responder Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Responder Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)

@App.route('/lerMensagens', methods=['GET'])
def lerMensagensGet():
    Response['Dados'] = lerMensagens()
    return J(Response)

@App.route('/lerProfessores', methods=['GET'])
def lerProfessoresGet():
    Response['Dados'] = lerProfessores()
    return J(Response)

@App.route('/lerAlunos', methods=['GET'])
def lerAlunosGet():
    Response['Dados'] = lerAlunos()
    return J(Response)

@App.route('/enviarMensagem2/<id>', methods=['POST'])
def enviarMensagemIdPost2(id):
    Response['Dados'] = enviarMensagem2(id)
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Enviar Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Enviar Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)

@App.route('/responderMensagem2/<id>/<mensagem>', methods=['POST'])
def responderMensagemIdPost2(id, mensagem):
    Response['Dados'] = alunoResponderMensagem(id, mensagem)
    if Response['Dados'] != '':
        Response['Mensagem'] = 'Responder Mensagem'
        Response['Status'] = 'Sucesso'
    else:
        Response['Mensagem'] = 'Responder Mensagem'
        Response['Status'] = 'Não Encontrado'
    return J(Response)