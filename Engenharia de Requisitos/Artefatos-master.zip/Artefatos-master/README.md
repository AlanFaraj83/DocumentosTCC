# Artefatos Engenharia de Software

Grupo 1

Alan Merhy Faraj     RA:1700103
Antonio Vicente      RA:1700735
Evelyn Helena        RA:1700607
Gabriel Coelho       RA:1700204
Mayara Silva         RA:1700521
Rodolfo Rodrigues    RA:1700248
